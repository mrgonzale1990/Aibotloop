# MauroRubenGonzalez-saibotloop
Certain ages aren't allowed in. Ai bot loop returns accepted user's name.
contact: Maurogonzalezplus@gmail.com
